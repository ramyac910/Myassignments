import dotenv from 'dotenv';
dotenv.config();
import { Groq } from 'groq-sdk';

const apiKey = process.env.GROQ_API_KEY;
const baseURL = process.env.GROQ_BASE_URL || undefined;
if (!apiKey) {
  console.error('GROQ_API_KEY is missing in .env');
  process.exit(1);
}

const client = new Groq({ apiKey, baseURL });
console.log('Groq client created');
console.log('baseURL:', client.baseURL);
console.log('getUserAgent():', client.getUserAgent());
console.log('Available top-level keys:', Object.keys(client));

process.exit(0);
