import dotenv from 'dotenv';
dotenv.config();
import { Groq } from 'groq-sdk';

const apiKey = process.env.GROQ_API_KEY;
const baseURL = process.env.GROQ_BASE_URL || undefined;
if (!apiKey) {
  console.error('GROQ_API_KEY is missing in .env');
  process.exit(1);
}

const client = new Groq({ apiKey, baseURL });

const prompt = 'Write a one-line product description for a laptop.';
try {
  const response = await client.chat.completions.create({
    model: 'openai/gpt-oss-20b',
    messages: [{ role: 'user', content: prompt }],
  });

  console.log(response.choices[0]?.message?.content ?? 'No response content returned.');
} catch (err) {
  console.error('Groq API error:');
  console.error(err);
  process.exit(1);
}
