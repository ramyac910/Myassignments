#!/usr/bin/env node
require('dotenv').config();
const { Groq } = require('groq-sdk');

(async () => {
  const apiKey = process.env.GROQ_API_KEY;
  const baseURL = process.env.GROQ_BASE_URL || undefined;
  if (!apiKey) {
    console.error('GROQ_API_KEY is missing in .env');
    process.exit(1);
  }

  const client = new Groq({ apiKey, baseURL });
  try {
    const prompt = 'Write a one-line product description for a laptop.';
    const res = await client.completions.post('', { body: { model: 'gpt-1', input: prompt } });
    console.log('Groq response:');
    console.log(JSON.stringify(res, null, 2));
  } catch (err) {
    console.error('Groq API error:');
    console.error(err);
    process.exit(1);
  }
})();
