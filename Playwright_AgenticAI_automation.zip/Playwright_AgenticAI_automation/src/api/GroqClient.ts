import dotenv from 'dotenv';
import { Groq } from 'groq-sdk';

dotenv.config();

const apiKey = process.env.GROQ_API_KEY?.trim();
const baseURL = process.env.GROQ_BASE_URL?.trim();

if (!apiKey) {
  throw new Error('GROQ_API_KEY is missing. Set it in your .env file.');
}

const client = new Groq({ apiKey, baseURL });

export async function runCompletion(prompt: string) {
  try {
    const res = await client.chat.completions.create({
      model: 'openai/gpt-oss-20b',
      messages: [{ role: 'user', content: prompt }],
    });
    // The SDK wraps responses — return the raw value conservatively
    return res;
  } catch (err) {
    throw err;
  }
}

export default client;
