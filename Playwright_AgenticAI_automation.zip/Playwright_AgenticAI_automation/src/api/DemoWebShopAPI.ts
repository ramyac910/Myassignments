import { request } from '@playwright/test';

export type AuthResponse = {
  cookies: string[];
  headers: Record<string, string>;
};

export default class DemoWebShopAPI {
  private readonly baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  async login(email: string, password: string) {
    const requestContext = await request.newContext({ baseURL: this.baseUrl });
    const response = await requestContext.post('/login', {
      form: {
        Email: email,
        Password: password,
        RememberMe: 'false'
      }
    });
    const cookies = await requestContext.cookies();
    await requestContext.dispose();
    return { response, cookies };
  }
}
