import { test as baseTest, expect } from '@playwright/test';
import CartPage from '../pages/CartPage';
import LoginPage from '../pages/LoginPage';
import ProductsPage from '../pages/ProductsPage';
import RegisterPage from '../pages/RegisterPage';

const test = baseTest.extend<{ loginPage: LoginPage; productsPage: ProductsPage; cartPage: CartPage; registerPage: RegisterPage }>( {
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },
  productsPage: async ({ page }, use) => {
    await use(new ProductsPage(page));
  },
  cartPage: async ({ page }, use) => {
    await use(new CartPage(page));
  },
  registerPage: async ({ page }, use) => {
    await use(new RegisterPage(page));
  }
});

export { test, expect };
