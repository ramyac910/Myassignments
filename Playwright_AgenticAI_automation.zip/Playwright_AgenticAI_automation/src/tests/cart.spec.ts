import { test, expect } from './fixtures';

test.describe('Cart flow', () => {
  test('should add a product to cart and navigate to cart', async ({ page, productsPage, cartPage }) => {
    await productsPage.goto();
    await productsPage.openFirstProduct();
    await page.click('input[value="Add to cart"]');
    await expect(page.locator('.bar-notification')).toContainText('The product has been added to your shopping cart');

    await cartPage.goto();
    await expect(await cartPage.itemCount()).toBeGreaterThan(0);
  });

  test('should proceed to checkout when terms are accepted', async ({ page, productsPage, cartPage }) => {
    await productsPage.goto();
    await productsPage.openFirstProduct();
    await page.click('input[value="Add to cart"]');
    await expect(page.locator('.bar-notification')).toContainText('The product has been added to your shopping cart');

    await cartPage.goto();
    await cartPage.acceptTerms();
    await cartPage.checkout();
    await expect(page).toHaveURL(/checkout/);
  });
});
