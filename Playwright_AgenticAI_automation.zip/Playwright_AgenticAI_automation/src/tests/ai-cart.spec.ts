import { test, expect } from './fixtures';
import PlaywrightAgent from '../agent/PlaywrightAgent';

test('AI-assisted cart flow with Playwright agent', async ({ page, productsPage, cartPage }) => {
  const agent = new PlaywrightAgent(page);

  await productsPage.goto();
  const selector = await agent.chooseNonGiftProduct();
  console.log('AI suggested selector:', selector);

  if (!selector) {
    throw new Error('Agent did not return a selector.');
  }

  await page.click(selector);
  await page.click('input[value="Add to cart"]');
  await expect(page.locator('.bar-notification')).toContainText('The product has been added to your shopping cart');

  await cartPage.goto();
  await cartPage.acceptTerms();
  await cartPage.checkout();
  await expect(page).toHaveURL(/checkout/);
});
