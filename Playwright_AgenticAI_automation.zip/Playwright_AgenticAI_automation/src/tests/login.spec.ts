import { test, expect } from './fixtures';

test.describe('Authentication flow', () => {
  test('should register a new account and sign in successfully', async ({ registerPage, loginPage }) => {
    const email = `playwright+${Date.now()}@example.com`;
    const password = 'P@ssw0rd123';

    await registerPage.goto();
    await registerPage.register('Test', 'User', email, password);
    await expect(await registerPage.getSuccessMessage()).toContain('Your registration completed');

    await loginPage.logout();
    await loginPage.goto();
    await loginPage.login(email, password);
    await expect(await loginPage.isLoggedIn()).toBeTruthy();
  });

  test('should show validation error when credentials are invalid', async ({ loginPage }) => {
    await loginPage.goto();
    await loginPage.login('invalid@example.com', 'wrongpassword');
    await expect(await loginPage.getErrorMessage()).toContain('Login was unsuccessful');
  });
});
