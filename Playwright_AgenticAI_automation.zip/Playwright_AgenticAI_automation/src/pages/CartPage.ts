import BasePage from './BasePage';
import { Page } from '@playwright/test';

export default class CartPage extends BasePage {
  private readonly cartItems = '.cart-item-row';
  private readonly termsCheckbox = '#termsofservice';
  private readonly checkoutButton = '#checkout';
  private readonly cartQuantity = '.qty-input';

  constructor(page: Page) {
    super(page);
  }

  async goto() {
    await this.navigate('/cart');
  }

  async acceptTerms() {
    await this.page.locator(this.termsCheckbox).waitFor({ state: 'visible', timeout: 10000 });
    await this.page.locator(this.termsCheckbox).check();
  }

  async checkout() {
    await this.click(this.checkoutButton);
  }

  async itemCount() {
    return this.page.locator(this.cartItems).count();
  }

  async getCartQuantity() {
    return this.page.locator(this.cartQuantity).inputValue();
  }
}
