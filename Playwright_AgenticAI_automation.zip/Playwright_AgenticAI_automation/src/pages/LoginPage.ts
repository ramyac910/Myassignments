import BasePage from './BasePage';
import { Page } from '@playwright/test';

export default class LoginPage extends BasePage {
  private readonly emailInput = '#Email';
  private readonly passwordInput = '#Password';
  private readonly loginButton = 'input.button-1.login-button';
  private readonly logoutLink = 'a[href="/logout"]';
  private readonly errorMessage = '.message-error, .validation-summary-errors';

  constructor(page: Page) {
    super(page);
  }

  async goto() {
    await this.navigate('/login');
  }

  async login(email: string, password: string) {
    await this.fill(this.emailInput, email);
    await this.fill(this.passwordInput, password);
    await Promise.all([
      this.page.waitForNavigation({ waitUntil: 'domcontentloaded' }),
      this.page.locator(this.loginButton).click()
    ]);
  }

  async isLoggedIn() {
    return this.page.locator(this.logoutLink).isVisible({ timeout: 10000 });
  }

  async logout() {
    if (await this.isLoggedIn()) {
      await Promise.all([
        this.page.waitForNavigation({ waitUntil: 'domcontentloaded' }),
        this.click(this.logoutLink)
      ]);
    }
  }

  async getErrorMessage() {
    return this.page.locator(this.errorMessage).first().textContent();
  }
}
