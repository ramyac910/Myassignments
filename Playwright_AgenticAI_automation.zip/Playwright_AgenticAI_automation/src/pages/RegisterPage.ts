import BasePage from './BasePage';
import { Page } from '@playwright/test';

export default class RegisterPage extends BasePage {
  private readonly firstNameInput = '#FirstName';
  private readonly lastNameInput = '#LastName';
  private readonly emailInput = '#Email';
  private readonly passwordInput = '#Password';
  private readonly confirmPasswordInput = '#ConfirmPassword';
  private readonly registerButton = 'input#register-button';
  private readonly successMessage = '.result';

  constructor(page: Page) {
    super(page);
  }

  async goto() {
    await this.navigate('/register');
  }

  async register(firstName: string, lastName: string, email: string, password: string) {
    await this.fill(this.firstNameInput, firstName);
    await this.fill(this.lastNameInput, lastName);
    await this.fill(this.emailInput, email);
    await this.fill(this.passwordInput, password);
    await this.fill(this.confirmPasswordInput, password);
    await Promise.all([
      this.page.waitForNavigation({ waitUntil: 'domcontentloaded' }),
      this.page.locator(this.registerButton).click()
    ]);
  }

  async getSuccessMessage() {
    return this.getText(this.successMessage);
  }
}
