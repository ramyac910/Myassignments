import BasePage from './BasePage';
import { Page } from '@playwright/test';

export default class ProductsPage extends BasePage {
  private readonly searchInput = '#small-searchterms';
  private readonly searchButton = '.search-box-button';
  private readonly firstProduct = '.product-item .product-title a';
  private readonly shoppingCartLink = '.cart-label';

  constructor(page: Page) {
    super(page);
  }

  async goto() {
    await this.navigate('/');
  }

  async searchFor(term: string) {
    await this.fill(this.searchInput, term);
    await this.click(this.searchButton);
  }

  async openFirstProduct() {
    await this.page.locator(this.firstProduct).filter({ hasNotText: 'Gift Card' }).first().click();
  }

  async goToCart() {
    await this.click(this.shoppingCartLink);
  }
}
