import { Page } from '@playwright/test';
import { queryAI } from './AgentClient';

export default class PlaywrightAgent {
  constructor(private page: Page) {}

  async chooseNonGiftProduct() {
    const prompt = `You are an automation assistant. On the current page, choose the best product link to add to cart. The product should not be a gift card. Return just the selector for the first valid item link.`;
    const answer = await queryAI(prompt);
    const trimmed = answer?.trim();
    if (trimmed) return trimmed;

    // Fallback: find the first product link that is not a Gift Card,
    // mark it with a data attribute and return that selector so tests can click it.
    const locator = this.page.locator('.product-item .product-title a').filter({ hasNotText: 'Gift Card' }).first();
    const exists = await locator.count();
    if (!exists) return '';
    await locator.evaluate((el: Element) => el.setAttribute('data-ai-suggest', 'true'));
    return '[data-ai-suggest="true"]';
  }

  async summarizePage() {
    const title = await this.page.title();
    const url = this.page.url();
    const prompt = `You are an automation agent. The page title is: ${title}. The URL is: ${url}. Based on this, what is the best next step for shopping or checkout?`;
    return queryAI(prompt);
  }
}

// This is the code block that represents the suggested code change:
// OPENAI_API_KEY=sk-...
