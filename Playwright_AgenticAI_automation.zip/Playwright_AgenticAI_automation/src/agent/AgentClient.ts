import OpenAI from 'openai';
import dotenv from 'dotenv';

dotenv.config();

const apiKey = process.env.OPENAI_API_KEY?.trim();
const allowMissing = process.env.ALLOW_MISSING_OPENAI === 'true';
let client: OpenAI | null = null;
if (!apiKey) {
  if (!allowMissing) {
    throw new Error(
      'OpenAI API key is missing. Set OPENAI_API_KEY in your .env file or environment variables.'
    );
  } else {
    console.warn('OPENAI_API_KEY is missing; running in fallback mode (ALLOW_MISSING_OPENAI=true).');
  }
} else {
  client = new OpenAI({ apiKey });
}

export async function queryAI(prompt: string) {
  if (!prompt?.trim()) {
    throw new Error('queryAI prompt is required.');
  }
  if (!client) {
    // Fallback: return an empty string so tests can run without an API key.
    console.warn('queryAI: OpenAI client not initialized — returning empty string.');
    return '';
  }
  const response = await client.responses.create({
    model: 'gpt-4.1-mini',
    input: prompt
  });

  const text = response.output?.[0]?.content?.[0]?.text;
  return text?.toString() ?? '';
}
