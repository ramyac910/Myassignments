# Playwright DemoWebShop Framework

A TypeScript Playwright framework built for https://demowebshop.tricentis.com using the Page Object Model, fixtures, API layer, reporting, and GitHub Actions.

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   npm run install:browsers
   ```

2. Run tests:
   ```bash
   npm test
   ```

3. View report:
   ```bash
   npm run report
   ```

## Framework Structure

- `src/pages` - Page Object Model classes
- `src/api` - API layer for backend interactions
- `src/tests` - Playwright test suites
- `.github/workflows` - CI workflow for GitHub Actions
- `playwright.config.ts` - Playwright configuration

## Groq SDK (optional)

This project includes an optional `groq-sdk` integration example. To use it:

1. Set environment variables in `.env`:
   ```env
   GROQ_API_KEY=your_groq_api_key_here
   GROQ_BASE_URL=https://api.groq.com # optional
   ```

2. Use the client in `src/api/GroqClient.ts` to call the Groq API. Example:
   ```ts
   import { runCompletion } from 'src/api/GroqClient';

   const out = await runCompletion('Write a short product description for a laptop');
   console.log(out);
   ```
